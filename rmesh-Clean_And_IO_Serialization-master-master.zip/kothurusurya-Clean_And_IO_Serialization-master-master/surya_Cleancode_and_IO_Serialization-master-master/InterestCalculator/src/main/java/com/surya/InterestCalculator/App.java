package com.surya.InterestCalculator;

/**
 * Hello world!
 *
 */
public class App 
{

}
